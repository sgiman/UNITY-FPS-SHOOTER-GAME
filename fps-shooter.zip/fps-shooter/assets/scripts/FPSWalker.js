//=============================================
// FPSWalker.js
//=============================================
// Created by Graham McAllister 2009-2011
// Modified by Sergey Gasanov (sgiman) 2012
//---------------------------------------------
var speed = 6.0;
var jumpSpeed = 8.0;
var gravity = 20.0;

private var moveDirection = Vector3.zero;
private var grounded : boolean = false;

function FixedUpdate() {
	if (grounded) {
		// Пересчитать направления движения непосредственно для всех осей (изменить Input)
		moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		moveDirection = transform.TransformDirection(moveDirection);
		moveDirection *= speed; // перемещения в послкости XZ c учетом скорости speed
		
		if (Input.GetButton ("Jump")) {
			moveDirection.y = jumpSpeed; // величина вертикальных прыжков по Y
		}
	}

	// Применить гравитацию
	moveDirection.y -= gravity * Time.deltaTime; // значение гравитации для каждого фрейма
	
	// Переместить контроллер
 	var controller : CharacterController = GetComponent(CharacterController); // получить доступ к CharacterController
	var flags = controller.Move(moveDirection * Time.deltaTime); // Перемещать персонаж-FPS к каждом кадре на величину moveDirection 
  grounded = (flags & CollisionFlags.CollidedBelow) != 0; // Флаг (grounded) столкновения с землей    
}

// Выполнить если присоединен CharacterController
@script RequireComponent(CharacterController)
