//============================================
// Rocket.js
// (Ракета)
//=============================================
// Created by Graham McAllister 2009-2011
// Modified by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

// Ссылка на prefab для взрыва
var explosion : GameObject;
var timeOut = 3.0;

// Уничтожать ракеты пока идет автоматический огонь
function Start () {
	Invoke("Kill", timeOut);
}


function OnCollisionEnter (collision : Collision) {
	// Инициализировать взрыв в контактной точке 
	// и вращать взрывом вдоль лицевой стороны по оси-y поверхности нормали 
	var contact : ContactPoint = collision.contacts[0];
	var rotation = Quaternion.FromToRotation(Vector3.up, contact.normal);
  Instantiate (explosion, contact.point, rotation); //???? для бесконечности....

	// и удалить ракету
	Kill ();    
}

function Kill () {
	// Остановить все прикрепленные эммитеры частиц к ракете  
	var emitter : ParticleEmitter= GetComponentInChildren(ParticleEmitter);
	if (emitter)
		emitter.emit = false;

	// Отключить детей - мы это отсоединяем в trail rendererer, пока установлено автоматическое уничтожение   
	transform.DetachChildren();
		
	// Удалить ракету
	Destroy(gameObject);
}

// проверить на Rigidbody перед исполнением скрипта
@script RequireComponent (Rigidbody)

