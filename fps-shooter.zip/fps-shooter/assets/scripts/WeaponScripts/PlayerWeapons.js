//=============================================
// PlayerWeapons.js
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

function Start () {
	// Выбор первого оружия
	SelectWeapon(0); // MachiheGun
}

function Update () {
	// Открыть огонь если нажато fire?
	if (Input.GetButton ("Fire1"))
		BroadcastMessage("Fire");
	
	if (Input.GetKeyDown("1")) {
		SelectWeapon(0); // MachiheGun
	}	
	else if (Input.GetKeyDown("2")) {
		SelectWeapon(1); // RocketLauncher
	}	
}

function SelectWeapon (index : int) {
	for (var i=0;i<transform.childCount;i++)	{
		// Активировать выбранное оружие
		if (i == index)
			transform.GetChild(i).gameObject.SetActiveRecursively(true);
		// Деактивировать все другие оружия
		else
			transform.GetChild(i).gameObject.SetActiveRecursively(false);
	}
}
