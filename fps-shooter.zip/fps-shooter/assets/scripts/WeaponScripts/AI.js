//=============================================
// AI.js
// Скрипт простого искусственного 
// интеллекта поведения ботов 
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

var speed = 3.0; // Скорость перемещения ботов
var rotationSpeed = 5.0; // Скорость вращения ботов
var shootRange = 15.0; // Дистанция для стрелбы
var attackRange = 30.0; // Радиус для атаки 
var shootAngle = 4.0; // Угол стрельбы
var dontComeCloserRange = 5.0; // Дистанция  - не подходить ближе 
var delayShootTime = 0.35; // Задержка для вспышки выстрела
var pickNextWaypointDistance = 2.0; // Дистанция  для следующей точки пути  
var target : Transform; // Координаты игрока-цели

private var lastShot = -10.0;

// Убедиться, что подключен CharacterController к боту
@script RequireComponent (CharacterController)

//--- Start ---//
function Start () {
	// Автоматически установить игрока как цель с его тегом "Player"
	if (target == null && GameObject.FindWithTag("Player"))
		target = GameObject.FindWithTag("Player").transform; // игрок найден

	Patrol();
}

//--- Patrol ---//
function Patrol () {
	var curWayPoint = AutoWayPoint.FindClosest(transform.position); // текущая ближайшая точка пути
	while (true) {
		var waypointPosition = curWayPoint.transform.position;
		// автоматическое уничтожение
		if (Vector3.Distance(waypointPosition, transform.position) < pickNextWaypointDistance)
			curWayPoint = PickNextWaypoint (curWayPoint);

		// Атака игрока и ждать, пока:
		// - игрок убил
		// - игрок находится вне поля зрения	
		
		if (CanSeeTarget ()) // Если в поле зрения - Aтаковать игрока-цель
			yield StartCoroutine("AttackPlayer"); // ожидать атаку игрока
		
		// Перемещение по отношению к нашей цели
		MoveTowards(waypointPosition);
		
		yield; // пауза на один фрейм
	}
}

//--- CanSeeTarget ---//
function CanSeeTarget () : boolean {
	if (Vector3.Distance(transform.position, target.position) > attackRange) // если дальше зоны атаки
		return false;
		
	var hit : RaycastHit; // физ. трассировка траектории попавшего снаряда
	if (Physics.Linecast (transform.position, target.position, hit)) // если на линии прицеливания
		return hit.transform == target; // цель есть  

	return false; // иначе нет цели
}

//--- Shoot ---//
function Shoot () {
	// Анимация начала стрельбы 
	animation.CrossFade("shoot", 0.3); // угасить вспышку выстрела

	// Подождать, пока проиграет половина анимации выстрела
	yield WaitForSeconds(delayShootTime);
	
	// Огонь
	BroadcastMessage("Fire");
	
	// Подождать, пока остальная анимация выстрела закочится до конца
	yield WaitForSeconds(animation["shoot"].length - delayShootTime);
}

//--- AttackPlayer ---//
function AttackPlayer () {
	var lastVisiblePlayerPosition = target.position;
	while (true) {
		if (CanSeeTarget ()) {
			// Цель уничтожена - стоп охоты
			if (target == null) // если больше не видно цель 
				return;

			// Цель находится слишком далеко - отказаться
			var distance = Vector3.Distance(transform.position, target.position);
			if (distance > shootRange * 3) // Если дистанция больше в три раза радиуса стрельбы
				return;
			
			lastVisiblePlayerPosition = target.position; //  эапомнить последнюю видимую позицию игрока
			
			if (distance > dontComeCloserRange) // если дистанция более чем дистанция "Не подходи ближе" 
				MoveTowards (lastVisiblePlayerPosition); // идти к последней видимой позици игрока
			else
				RotateTowards(lastVisiblePlayerPosition); // и повернуться  в эту сторону игрока 

			var forward = transform.TransformDirection(Vector3.forward); // двигаться вперед
			
			var targetDirection = lastVisiblePlayerPosition - transform.position; // новая позиция к цели
			targetDirection.y = 0;

			var angle = Vector3.Angle(targetDirection, forward); // угол к цели 

			// Начать огонь, если близко и продолжается игра
			if (distance < shootRange && angle < shootAngle) // если дистанция и угол срельбы в норме 
				yield StartCoroutine("Shoot"); // ожидать начало огня один фрейм
		} else { // иначе повторно искать игрока 
			yield StartCoroutine("SearchPlayer", lastVisiblePlayerPosition);
			// Игрока не видно больше - прекратить нападения
			if (!CanSeeTarget ()) // Если цель не видна - ВЫЙТИ ... 
				return;
		}

		yield;
	}
}

//--- SearchPlayer ---//
function SearchPlayer (position : Vector3) {
	// Бежать к игроку, но после 3 секунд тайм-аут и вернуться к патрулирования
	var timeout = 3.0;
	while (timeout > 0.0) { // искать игрока 3 сек
		MoveTowards(position); // движение вперед

		// Если Игрок обнаружен
		if (CanSeeTarget ())
			return; //Выйти из цикла

		timeout -= Time.deltaTime; // уменьшить время поиска на один фрейм    
		yield; // Ждать один фрейм 
	}
}

//--- RotateTowards ---//
//Пренуться вперед к камере игрока  
function RotateTowards (position : Vector3) {
	SendMessage("SetSpeed", 0.0);
	
	var direction = position - transform.position; // новая позиция
	direction.y = 0; // на земле
	if (direction.magnitude < 0.1) // если некуда далее поворачиваться 
		return; // выйти
	
	// Поворот к цели
	transform.rotation = Quaternion.Slerp (transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
	transform.eulerAngles = Vector3(0, transform.eulerAngles.y, 0);
}

//--- MoveTowards ---//
// Двигаться  вперед 
function MoveTowards (position : Vector3) {
	var direction = position - transform.position;
	direction.y = 0;
	if (direction.magnitude < 0.5) {
		SendMessage("SetSpeed", 0.0);
		return;
	}
	
	// Поворот к цели
	
	// расчет угда поворота для новой позиции
	transform.rotation = Quaternion.Slerp (transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
	// угол поворота в градусах
	transform.eulerAngles = Vector3(0, transform.eulerAngles.y, 0);

	// Изменить скорость, поэтому мы замедлимся, когда мы не лицом к цели
	var forward = transform.TransformDirection(Vector3.forward); // новая позиция "вперед"
	var speedModifier = Vector3.Dot(forward, direction.normalized); // коэф-т замедления скорости
	speedModifier = Mathf.Clamp01(speedModifier); // новое замедление движения 

	//**** Переместить персонаж  с учетом скорости и замедления!!! ****// 
	direction = forward * speed * speedModifier;
	GetComponent (CharacterController).SimpleMove(direction); // Cвязаться с контроллером и задать новое перемещение   
	SendMessage("SetSpeed", speed * speedModifier, SendMessageOptions.DontRequireReceiver);
}

//--- PickNextWaypoint ---//
// Указать следующую точку пути
function PickNextWaypoint (currentWaypoint : AutoWayPoint) {
	// Мы хотим найти точку, где персонаж должен двигаться

	// Направление, в котором мы идем
	var forward = transform.TransformDirection(Vector3.forward);

	// Чем ближе двух векторов, тем больше скалярное произведение будет.
	var best = currentWaypoint; // текущая точка пути 
	var bestDot = -10.0; // назад на шаг -10

	for (var cur : AutoWayPoint in currentWaypoint.connected) {
		var direction = Vector3.Normalize(cur.transform.position - transform.position); // новое направление движения
		var dot = Vector3.Dot(direction, forward); // новая точка по пути вперед
		if (dot > bestDot && cur != currentWaypoint) { // Если новая дистанция  > -10 и не на текущей точке пути
				bestDot = dot; // запомнить новую дистанцию
				best = cur; ///  запомнить новую точку пути
		}
	}
	
	return best;
}
