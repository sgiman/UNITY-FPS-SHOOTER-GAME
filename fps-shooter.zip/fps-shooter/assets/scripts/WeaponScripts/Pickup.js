//=============================================
// Pickup.js
// (Здоровье)
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------
enum PickupType { Health = 0, Rocket = 1 } // Тип выбора для пополнения счетчиков (Здоровье,Ракеты) 
var pickupType = PickupType.Health; // Тип "Здоровье" 
var amount = 20; // кол-во пополнения
var sound : AudioClip; // Звук триггера


//-------------------
// OnTriggerEnter
//-------------------
// Включить триггер столкновения
private var used = false; // флаг использования пополнения 

function OnTriggerEnter (col : Collider) {
	var player : FPSPlayer = col.GetComponent(FPSPlayer); // Подключиться к скрипту FPSPlayer для колайдера
	
	//* Убедиться, что мы бежим к игроку
	//* предотвратить нажатие курка дважды, потому что уничтожение
	//  может быть отложено до того, как анимация закончится
	if (used || player == null) // если нет столконвения с игроком и уже использовано - выйти 
		return; 
	
	if (!ApplyPickup (player)) // Если уже было пополнение - также выйти
		return;
	
	used = true; // "использовано" 
	
	// Проиграть звук,  если он присоединен...
	if (sound)
		AudioSource.PlayClipAtPoint(sound, transform.position);
	
	// Если есть анимация, то присоединить ее.
	// Проиграть это.
	if (animation && animation.clip) { // если есть компонента анимации с анимационным клипом,
		animation.Play(); // то проиграть анимацию
		Destroy(gameObject, animation.clip.length); // и затем уничтожить анимацинный объект 
	} else {
		Destroy(gameObject); // иначе прсто уничтожить объект 
	}
}


//-------------------
// ApplyPickup
//-------------------
// Применить пополнение
function ApplyPickup (player : FPSPlayer) {
	// Если столкнулись со "ЗДОРОВЬЕМ" 
	if (pickupType == PickupType.Health) {
		if (player.hitPoints >= player.maximumHitPoints)
			return false; // ничего не пополнять, если есть еще резерв
		player.hitPoints += amount; // пополнить здоровье
		player.hitPoints = Mathf.Min(player.hitPoints, player.maximumHitPoints); // усреднить по минимому 
	} else if (pickupType == PickupType.Rocket) { 	// иначе если столкнулись с "РАКЕТАМИ" 
		var launcher : RocketLauncher = player.GetComponentInChildren(RocketLauncher); // обратиться к cкрипту RocketLauncher
		if (launcher) // если используется ракетница
			launcher.ammoCount += amount; // пополнить боезапас ракетами
	}
	
	return true;
}


//-------------------
// Reset (Сбросить)
//-------------------
// Автоматическая настройка pickup
function Reset () {
	if (collider == null)	
		gameObject.AddComponent(BoxCollider);
	collider.isTrigger = true;
}

