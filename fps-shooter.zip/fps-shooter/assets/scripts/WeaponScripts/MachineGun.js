//=============================================
// MachineGun.js
// Пулемет-Автомат
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------
var range = 100.0;
var fireRate = 0.05;
var force = 10.0;
var damage = 10.0;
var bulletsPerClip = 40;
var clips = 20;
var reloadTime = 0.5;
private var hitParticles : ParticleEmitter;
var muzzleFlash : Renderer;

private var bulletsLeft : int = 0;
private var nextFireTime = 0.0;
private var m_LastFrameShot = -1;

//-----------------------
// Start
//-----------------------
function Start () {
	hitParticles = GetComponentInChildren(ParticleEmitter);
	
	// Испускать частицы не все время, а  только тогда, когда мы попали во что-нибудь.
	if (hitParticles)
		hitParticles.emit = false;
	bulletsLeft = bulletsPerClip;
}

//-----------------------
// LateUpdate
//-----------------------
function LateUpdate() {
	if (muzzleFlash) {
		// Мы стрельнули  в этом кадре, включить вспышку
		if (m_LastFrameShot == Time.frameCount) {
			muzzleFlash.transform.localRotation = Quaternion.AngleAxis(Random.value * 360, Vector3.forward);
			muzzleFlash.enabled = true;

			if (audio) {
				if (!audio.isPlaying)
					audio.Play();
				audio.loop = true;
			}
		} else {
		// Не отключать вспышку
			muzzleFlash.enabled = false;
			enabled = false;
			
			// Проиграть звук
			if (audio)
			{
				audio.loop = false;
			}
		}
	}
}


//-----------------------
// Fire
//-----------------------
function Fire () {
	if (bulletsLeft == 0)
		return;
	
	// Если есть больше чем одна пуля между последним и этим кадром
	// Сброс nextFireTime	если (Time.time - fireRate > nextFireTime)
	nextFireTime = Time.time - Time.deltaTime;
	
	// Продолжайте стрелять, пока не закончилось время огня 
	while( nextFireTime < Time.time && bulletsLeft != 0) {
		FireOneShot();
		nextFireTime += fireRate;
	}
}

//-----------------------
// FireOneShot
//-----------------------
function FireOneShot () {
	var direction = transform.TransformDirection(Vector3.forward);
	var hit : RaycastHit;
	
	// Если мы попали во что-нибудь?
	if (Physics.Raycast (transform.position, direction, hit, range)) {
		// Применить силу к Rigidbody в которую мы попали...
		if (hit.rigidbody)
			hit.rigidbody.AddForceAtPosition(force * direction, hit.point);
		
		// Установить систему частиц для запуска из места, где мы попали в поверхность!
		// и запустить систему частиц 
			if (hitParticles) {
			hitParticles.transform.position = hit.point;
			hitParticles.transform.rotation = Quaternion.FromToRotation(Vector3.up, hit.normal);
			hitParticles.Emit();
		}

		// Отправить сообщение о повреждения (hit) объекта		
		hit.collider.SendMessageUpwards("ApplyDamage", damage, SendMessageOptions.DontRequireReceiver);
	}
	
	bulletsLeft--;

	// Register that we shot this frame,
	// so that the LateUpdate function enabled the muzzleflash renderer for one frame
	// Зарегистрировать, что мы стреляли в этом кадре,
	// Так чтобы функция была включена в LateUpdate muzzleflash для визуализации одного кадра
	m_LastFrameShot = Time.frameCount;
	enabled = true;
	
	// Перезарядить оружие в отведенное время перезарядки	
	if (bulletsLeft == 0) // если патроны закончились
		Reload();			
}


//-----------------------
// Reload
// (перезарядка)
//-----------------------
function Reload () {

	// В начале ожидать завершения времени на перезарядку - потом добавить больше пуль!
	yield WaitForSeconds(reloadTime);

	// Если имеются магазины для перезардки  - то перезрядка
	if (clips > 0) {
		clips--;
		bulletsLeft = bulletsPerClip;
	}
//	else //*** Sgiman correct for Reload  - всегда перезарядка на 20 магазинов по 100 патронов ***
//		{
//			clips = 20;
//			bulletsPerClip = 40;
//		}	
}


//-----------------------
// GetBulletsLeft
//-----------------------
function GetBulletsLeft () {
	return bulletsLeft;
}

//-----------------------
// GetClipsLeft
//-----------------------
function GetClipsLeft () {
	return clips;
}
