//=============================================
// FPSPlayer.js
// FPS ИГРОК (наш вариант для crysis-shooter) 
//=============================================
// Created by Graham McAllister 2009-2011
// Modified by Sergey Gasanov (sgiman) 2012
//---------------------------------------------
var maximumHitPoints = 100.0; // Макс. значение ущерба
var hitPoints = 100.0; 				// Значение ущерба

var bulletGUI : GUIText;     	// Cчетик пуль
var rocketGUI : DrawRockets;	// Счетик ракет
var healthGUI : GUITexture;		// Счетчик здоровья

var walkSounds : AudioClip[];	// Звук ходьбы
var painLittle : AudioClip;		// Звук боли	
var painBig : AudioClip;			// Звук большой боли
var die : AudioClip;					// Звук смерти
var audioStepLength = 0.3;		// Длина звука ходьбы

private var machineGun : MachineGun;					// Пулемет
private var rocketLauncher : RocketLauncher;	// Ракетница
private var healthGUIWidth = 0.0;							// Ширина GUI-здоровье
private var gotHitTimer = -1.0;								// Таймер ударов 
var rocketTextures : Texture[];								// Тестуры для счетчика ракет

//---------------------
// Awake (идущий)
//---------------------
function Awake () {
	machineGun = GetComponentInChildren(MachineGun); 					// комопнента "пулемет"
	rocketLauncher = GetComponentInChildren(RocketLauncher);	// компонента "ракетница" 
	
	PlayStepSounds(); // шаги

	healthGUIWidth = healthGUI.pixelInset.width; // здоровье
}

//---------------------
// ApplyDamage (ущерб)
//---------------------
function ApplyDamage (damage : float) {
	if (hitPoints < 0.0)
		return;

	// Нанесенный ущерб
	hitPoints -= damage;

	// Проиграть звук боли, когда получили удар - но не играть часто
	if (Time.time > gotHitTimer && painBig && painLittle) {
		// Проиграть звук большой боли
		if (hitPoints < maximumHitPoints * 0.2 || damage > 20) { // если повреждения более или равны 20 попаданиям 
			audio.PlayOneShot(painBig, 1.0 / audio.volume);  // уровень звука
			gotHitTimer = Time.time + Random.Range(painBig.length * 2, painBig.length * 3); // таймер переодичности звука
		} else {
			// Проиграть большой звук боли
			audio.PlayOneShot(painLittle, 1.0 / audio.volume);
			gotHitTimer = Time.time + Random.Range(painLittle.length * 2, painLittle.length * 3);
		}
	}

	// Если мы мертвы?
	if (hitPoints < 0.0)
		Die();
}


//---------------------
// Die (смерть)
//---------------------
function Die () {
	if (die)
		AudioSource.PlayClipAtPoint(die, transform.position); // звук смерти в текущей позиции
	
	// Отключить все сценарии поведения (по существу отключение управления плеером)
	var coms : Component[] = GetComponentsInChildren(MonoBehaviour);
	for (var b in coms) {
		var p : MonoBehaviour = b as MonoBehaviour;
		if (p)
			p.enabled = false;
	}
	// Загрузить "Белый Фейд" для нового уровня
	LevelLoadFade.FadeAndLoadLevel(Application.loadedLevel, Color.white, 2.0);
}


//---------------------
// LateUpdate
//---------------------
function LateUpdate () {
	// Обновление GUI каждый кадр
	// Мы делаем это, в конце обновления, чтобы убедиться, что пулеметы и т.д. были уже выполнены
	UpdateGUI();
}


//---------------------
// PlayStepSounds (шаги)
//---------------------
function PlayStepSounds () {
	var controller : CharacterController = GetComponent(CharacterController);

	while (true) {
		if (controller.isGrounded && controller.velocity.magnitude > 0.3) { // если более интервала звука шагов - 0.3 сек..
			audio.clip = walkSounds[Random.Range(0, walkSounds.length)]; // один звук ходьбы выбранный случайным образом
			audio.Play(); // проиграть выбранный звук ходьбы
			yield WaitForSeconds(audioStepLength); // ждать до конца завершения звука
		} else {
			yield; // задержка на один фрейм
		}
	}
}


//---------------------
// UpdateGUI
//---------------------
function UpdateGUI () {
	// Обновление здоровье GUI
	// Здоровье графического интерфейса отображается с помощью наложения текстур которые уменьшаются на основе здоровье
	// - Рассчитать долю, сколько здоровья мы оставили (0 ... 1)
	var healthFraction = Mathf.Clamp01(hitPoints / maximumHitPoints);

	// - Отрегулировать максимальное кол-во пикселей health-текстуры для вставки
	healthGUI.pixelInset.xMax = healthGUI.pixelInset.xMin + healthGUIWidth * healthFraction;

	// Обновить пулемет-GUI
	// Пулемет GUI просто обращается к тексту - счетчик пуль (и магазины - clip)
	if (machineGun) {
		var nclips = machineGun. GetClipsLeft().ToString();
		bulletGUI.text = machineGun.GetBulletsLeft().ToString() + "/" + nclips;// кол-во патронов и магазинов
	}
	
	// Обновление ракеты GUI
	if (rocketLauncher)	{
		rocketGUI.UpdateRockets(rocketLauncher.ammoCount);
	}
}

