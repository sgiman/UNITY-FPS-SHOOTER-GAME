//=============================================
// RocketLauncherRobot.js
// (Ракетница робота)
//=============================================
// Created by Graham McAllister 2009-2011
// Modified by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

var projectile : Rigidbody;
var initialSpeed = 20.0;
var reloadTime = 0.5;
var ammoCount = 20;
private var lastShot = -10.0;

function Fire () {
	// Подошло ли время для перезарядки ?
	if (Time.time > reloadTime + lastShot && ammoCount > 0) {
		// Создать новый боезапас, ипользовать такую же  позицию и повoрот как у Ракетницы.
		var instantiatedProjectile : Rigidbody = Instantiate (projectile, transform.position, transform.rotation);
			
		// Задать начальную скорость вперед. Это направление вдоль оси-z для перемещения ракет ракетницы.   
		instantiatedProjectile.velocity = transform.TransformDirection(Vector3 (0, 0, initialSpeed));

		// Игнорировать столконвения ракеты с персонажем
		Physics.IgnoreCollision(instantiatedProjectile.collider, transform.root.collider);
		
		lastShot = Time.time;
		ammoCount--;
	}
}