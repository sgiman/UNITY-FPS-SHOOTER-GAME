//=============================================
// SentryGun.js
// (Пулемет на штативе)
//=============================================
// Created by Graham McAllister 2009-2011
// Modified by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

var attackRange = 30.0;
var shootAngleDistance = 10.0;
var target : Transform;

function Start () {
	if (target == null && GameObject.FindWithTag("Player"))
		target = GameObject.FindWithTag("Player").transform;
}


//-------------------------
// Update
//-------------------------
function Update () {
	if (target == null)
		return;
	
	if (!CanSeeTarget ())
		return;
	
	// Поворот к цели
	var targetPoint = target.position;
	var targetRotation = Quaternion.LookRotation (targetPoint - transform.position, Vector3.up);
	transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * 2.0);

	// Если цель видна -  повернуть в направлении цели - огонь один магазин патронов
	var forward = transform.TransformDirection(Vector3.forward);
	var targetDir = target.position - transform.position;
	if (Vector3.Angle(forward, targetDir) < shootAngleDistance)
		SendMessage("Fire");
}


//-------------------------
// CanSeeTarget
//-------------------------
function CanSeeTarget () : boolean
{
	if (Vector3.Distance(transform.position, target.position) > attackRange)
		return false;
		
	var hit : RaycastHit;
	if (Physics.Linecast (transform.position, target.position, hit))
		return hit.transform == target;

	return false;
}

