//=============================================
// AircraftDamageReceiver.js
// (for aircraft)  
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

var hitPoints = 100.0;
var detonationDelay = 0.0;
var explosion : Transform;
var deadReplacement : Transform;

//-------------------------
// ApplyDamage
//-------------------------
function ApplyDamage (damage : float) {
	// Если уровень ущерба hitPoints < 0, может быть уже Ridgibody убит?
	if (hitPoints <= 0.0)
		return;
		
	hitPoints -= damage;
	
	if (hitPoints <= 0.0) {
		// Запустить систему частиц
		var emitter : ParticleEmitter = GetComponentInChildren(ParticleEmitter);
		if (emitter)
			emitter.emit = true;

		Invoke("DelayedDetonate", detonationDelay);
	}
}

//-------------------------
// DelayedDetonate 
//-------------------------
function DelayedDetonate () {
	BroadcastMessage ("Detonate");
}

//-------------------------
// Detonate
//-------------------------
function Detonate () {
	// Уничтожить объект
	Destroy(gameObject);

	// Создать взрыв
	if (explosion)
		Instantiate (explosion, transform.position, transform.rotation);

	// Если попали в самолет, замещаем на горящий!
	if (deadReplacement) {
		var dead : Transform = Instantiate(deadReplacement, transform.position, transform.rotation);
		// Для лучшего эффекта назначить такую же скорость, что и взрываемому самолету 
		//dead.transform.velocity = transform.velocity;
		//dead.angularVelocity = transform.angularVelocity;
	}
	
	// Если систма частиц остановлена - сразу отключить, чтобы не разрушить это 
	var emitter : ParticleEmitter = GetComponentInChildren(ParticleEmitter);
	if (emitter) {
		emitter.emit = false;
		emitter.transform.parent = null;
	}
}

// Этот скрипт работает только с Rigidbody
//@script RequireComponent (Rigidbody)
