//=============================================
// CharacterDamage.js
// Повреждение пересонажа
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

var hitPoints = 100.0;
var deadReplacement : Transform;
var dieSound : AudioClip;

//----------------------
// ApplyDamage
//----------------------
function ApplyDamage (damage : float) {
	// У нас уже есть < 0 хитпоинтов, возможно, мы убили уже?
	if (hitPoints <= 0.0)
		return;

	hitPoints -= damage;
	if (hitPoints <= 0.0)
	{
		Detonate(); // Детонировать
	}
}

//----------------------
// Detonate
//----------------------
function Detonate () {
	// Уничтожить себя
	Destroy(gameObject);
	
	// Проиграть аудио-клип смерти
	if (dieSound)
		AudioSource.PlayClipAtPoint(dieSound, transform.position);

	//*** Заменить себя с мертвым телом (RagDolls) ***
	if (deadReplacement) {
		var dead : Transform = Instantiate(deadReplacement, transform.position, transform.rotation);
		
		// Скопировать положение и поворот от старой иерархии для замены мертвым телом 
		CopyTransformsRecurse(transform, dead);
	}
}

//------------------------
// CopyTransformsRecurse
//------------------------
static function CopyTransformsRecurse (src : Transform,  dst : Transform) {
	dst.position = src.position;
	dst.rotation = src.rotation;
	
	for (var child : Transform in dst) {
		// Подходящее преобразование с тем же именем
		var curSrc = src.Find(child.name);
		if (curSrc)
			CopyTransformsRecurse(curSrc, child);
	}
}
