//=============
// Exit
//=============
private var buttonWidth : int = 100; 
private var buttonHeight : int = 25;	

function OnGUI()
{   	 	 	    	
	GUILayout.BeginArea(Rect(300, 0, (buttonWidth+2)*7, 100));
	GUILayout.BeginHorizontal();

	// Botton FULLSCREEN        
	//if(GUILayout.Button("FullScreen", GUILayout.Height(buttonHeight)))
	//{
	//	Screen.fullScreen = !Screen.fullScreen; 
	//}

	// Botton EXIT 
	//if(GUILayout.Button("Exit", GUILayout.Height(buttonHeight)))
	//{
	//	 Application.Quit(); 
	//}
	
	GUILayout.Label ("A.S.W.D.Space - Navigation  |  0 - FPS  |  1 - MachineGun  |  2 - RocketLauncher");	
	GUILayout.EndHorizontal();
	GUILayout.EndArea();
}