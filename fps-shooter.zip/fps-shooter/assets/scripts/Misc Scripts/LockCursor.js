//=============================================
// LockCursor.js
// (only for WebPlayer)
//=============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------

//------------------ 
// Start
//------------------
function Start ()
{
	// Начать в режиме паузы в веб-плеере
	
	if (Application.platform == RuntimePlatform.OSXWebPlayer ||
	    Application.platform == RuntimePlatform.WindowsWebPlayer)
	{
		SetPause(true);
	}
	else
	{
		SetPause(false);
		Screen.lockCursor = true;
	}
}

//-------------------- 
// OnApplicationQuit
//--------------------
function OnApplicationQuit ()
{
	Time.timeScale = 1;
}

//------------------ 
// SetPause
//------------------
function SetPause (pause : boolean)
{
	Input.ResetInputAxes();
	var gos : Object[] = FindObjectsOfType(GameObject);
	for (var go : GameObject in gos)
		go.SendMessage("DidPause", pause, SendMessageOptions.DontRequireReceiver);
	
	transform.position = Vector3.zero;
	
	if (pause)
	{
		Time.timeScale = 0;
		transform.position = Vector3 (.5, .5, 0);
		guiText.anchor = TextAnchor.MiddleCenter;
	}
	else
	{
		guiText.anchor = TextAnchor.UpperLeft;
		transform.position = Vector3(0, 1, 0);
		Time.timeScale = 1;
	}
}

//------------------ 
// DidPause
//------------------
function DidPause (pause : boolean)
{
	if (pause)
	{
	    // Указать на кнопку еще раз
	    guiText.enabled = true;
			guiText.text = "Click to start playing";
	}
	else
	{
	    // Отключить кнопку
	    guiText.enabled = true;
	    guiText.text = "Escape to show the cursor";
	}
}


//------------------ 
// OnMouseDown
//------------------
function OnMouseDown ()
{
    // Lock the cursor
    Screen.lockCursor = true;
}


//------------------ 
// Update
//------------------
private var wasLocked = false;

function Update ()
{
	if (Input.GetMouseButton(0))
		Screen.lockCursor = true;

    // Мы потеряли cursor locking?
    // Например. потому что пользователь нажал escape
    // Или потому, что он переключился на другое приложение
    // Или потому, что некоторые cкрипты установлены для Screen.lockCursor = false; 

    if (!Screen.lockCursor && wasLocked)
    {
        wasLocked = false; // разблокировать курсор 
        SetPause(true); // установить паузу
    }
    // Разве мы получили cursor locking?
    else if (Screen.lockCursor && !wasLocked)
    {
        wasLocked = true; // заблокировать курсор
        SetPause(false); // выключить паузу 
    }
}

