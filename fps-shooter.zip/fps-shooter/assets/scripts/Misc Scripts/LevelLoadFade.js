//============================================
// LevelLoadFade.js
// Загрузка промежуточного уроня 
// "БЕЛЫЙ ФЕЙД"
//============================================
// Created by Graham McAllister 2009-2011
// Modifed by Sergey Gasanov (sgiman) 2012
//---------------------------------------------
/*
	Usage:

	// Загрузить уровень с "белым фейдом"	
	LevelLoadFade.FadeAndLoadLevel("mylevel", Color.white, 0.5);

	// Сбросить текущий уровень через "белый фейд"
	LevelLoadFade.FadeAndLoadLevel(Application.loadedLevel, Color.white, 0.5);
*/


//-----------------------
// FadeAndLoadLevel 
// (c внешей текстурой) 
//-----------------------

static function FadeAndLoadLevel (level, fadeTexture : Texture2D, fadeLength : float)
{
	if (fadeTexture == null)
		FadeAndLoadLevel(level, Color.white, fadeLength);

	var fade = new GameObject ("Fade");
	fade.AddComponent(LevelLoadFade);
	fade.AddComponent(GUITexture);
	fade.transform.position = Vector3 (0.5, 0.5, 1000);
	fade.guiTexture.texture = fadeTexture;
	fade.GetComponent(LevelLoadFade).DoFade(level, fadeLength, false);
}



//-----------------------
// FadeAndLoadLevel
// (c цветом) 
//-----------------------
static function FadeAndLoadLevel (level, color : Color, fadeLength : float)
{
	var fadeTexture = new Texture2D (1, 1);
	fadeTexture.SetPixel(0, 0, color);
	fadeTexture.Apply();
	
	var fade = new GameObject ("Fade");
	fade.AddComponent(LevelLoadFade);
	fade.AddComponent(GUITexture);
	fade.transform.position = Vector3 (0.5, 0.5, 1000);
	fade.guiTexture.texture = fadeTexture;

	DontDestroyOnLoad(fadeTexture);
	fade.GetComponent(LevelLoadFade).DoFade(level, fadeLength, true);
}


//-----------------------
// DoFade
// (выполнить фейд)
//-----------------------
function DoFade (level, fadeLength : float, destroyTexture : boolean)
{
	// Не уничтожать объекты текущего уровня  во время процесса фейда
	DontDestroyOnLoad(gameObject);

	// Начать затухание с...
	guiTexture.color.a = 0;
	
	// Затухание текстуры в...
	var time = 0.0;
	while (time < fadeLength)
	{
		time += Time.deltaTime;
		guiTexture.color.a = Mathf.InverseLerp(0.0, fadeLength, time);
		yield;
	}
	guiTexture.color.a = 1;
	yield;

	// Завершить исчезновение (Загрузить уровень и сбросить позицию игрока)
	Application.LoadLevel(1);
	
	// Fade текстуры 
	time = 0.0;
	while (time < fadeLength)
	{
		time += Time.deltaTime;
		guiTexture.color.a = Mathf.InverseLerp(fadeLength, 0.0, time);
		yield;
	}
	guiTexture.color.a = 0;
	yield;

	Destroy (gameObject);

	// Если бы мы создали текстуру из кода мы использовали DontDestroyOnLoad,
	// которая означает, что мы должны очистить его вручную, чтобы избежать утечек.
	if (destroyTexture)
		Destroy (guiTexture.texture);
}

