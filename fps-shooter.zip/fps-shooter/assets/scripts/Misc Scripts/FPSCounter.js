//===================================
// FPSCounter.js
// (FPS - Frames Per Seconds)
//===================================
// Created by Sgiman for testing game

private var show = false;

function Update () {
	if (Input.GetKeyDown("0"))
		show = !show;
	if (show)
	{
		guiTexture.enabled = true;
		guiText.enabled = true;
		
		if (Time.timeScale != 0.0)
		{
			var fps : int = 1.0 / Time.deltaTime;
			guiText.text = fps.ToString();
		}
		else
		{
			guiText.text = "0";
		}
	}
	else
	{
		guiText.text = "";	
		guiText.enabled = false;
		guiTexture.enabled = false;
	}
}

@script RequireComponent(GUITexture)
@script RequireComponent(GUIText)
