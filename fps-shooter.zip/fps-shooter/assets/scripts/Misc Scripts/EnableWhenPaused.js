var target : MonoBehaviour;

function DidPause (pause : boolean)
{
	target.enabled = pause;
}